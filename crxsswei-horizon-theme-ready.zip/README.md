# CRXSSWEI — Horizon Theme (Landing Page Build)

This package is the **Horizon** theme export (`crxsswei.myshopify.com`) with the
custom landing-page design from `design-handoff/landing-page/` implemented as a
native Shopify Liquid section. It is ready to upload as-is.

## What changed vs. the raw theme export

1. **`sections/landing-page.liquid`** (new) — the full-viewport splash screen:
   animated particle-field canvas, floating logo, live EST clock, glowing nav
   pills, a disabled "Coming Soon" slot, and Instagram/YouTube icons. Built
   pixel-accurate to `design-handoff/landing-page/README.md` using Horizon's
   own conventions (`{% stylesheet %}`, section-scoped script, `image_picker`,
   block-based nav links).
2. **`layout/landing.liquid`** (new) — a header/footer-free layout (same
   pattern Horizon already uses for `layout/password.liquid`). It still
   includes `content_for_header`, so theme/app-embed blocks (chat widget,
   preloader, confetti, etc.) keep working.
3. **`templates/index.json`** (replaced) — the homepage now renders only the
   `landing-page` section on the `landing` layout, so visitors land on the
   splash screen with no header/footer.
4. **`templates/page.shop.json`** (new) — your **original** homepage content
   (Hero + Featured Collection + Marquee) was moved here, unchanged, so
   nothing was lost. It's kept in the theme as an optional page template in
   case you ever want a dedicated "Shop" landing page in addition to your
   catalog — see below.
5. **`sections/contact-page.liquid`** (new) — the full-viewport contact
   screen from `design-handoff` (starfield canvas, "← BACK" link, CONTACT
   heading, minimalist Name/Email/Message form, social icons), built on a
   **real, working Shopify contact form** (`{% form 'contact' %}` — the same
   engine `blocks/contact-form.liquid` already used) so submissions actually
   reach your Shopify inbox and get spam-filtered like normal. On submit,
   Shopify reloads the page and this section shows "MESSAGE SENT — THANK
   YOU." in place of the status line, or the email-validation error if one
   occurred.
6. **`templates/page.contact.json`** (replaced) — your existing Contact page
   renders the `contact-page` section, matching the splash-screen aesthetic.
   The **← BACK** link returns to `/` (the landing page). It now runs on the
   **standard** theme layout (not the header-free `landing` layout), so the
   site nav bar and footer appear above/below it — see item 8.
7. **`snippets/site-skin.liquid`** (new) — a site-wide visual skin, rendered
   from `layout/theme.liquid` so it applies everywhere the standard Horizon
   header shows up (catalog, product pages, cart, search, blog, etc.):
   - **Header/nav**: white background, Bebas Neue wordmark and nav links
     (uppercase, letter-spaced), a subtle glow on hover/active — the same
     visual language as the landing page's nav pills, without changing any
     of the header's underlying functionality (mega menu, search modal,
     account, cart drawer all work exactly as before).
   - **Catalog grid**: filter labels ("Availability", "Price"), the item
     count, and the sort control now use Share Tech Mono, matching the
     landing page's clock/data styling. Product card titles and prices pick
     up the same mono treatment for a consistent "terminal" look.
   - This is pure CSS layered on top of the existing markup — no Liquid
     logic, JS, or functionality was touched, so cart, checkout, filtering,
     and search behave exactly as they did before.
   - Note: the skin forces the header to a solid white background, which
     will override Horizon's "transparent header" setting if you ever
     enable it (it's off by default in this theme).
8. **`sections/main-policy.liquid` + `templates/policies.json`** (new) — a
   real, styled Policies page. Horizon's raw export ships **no** template for
   `/policies`, so Shopify was falling back to its generic, unbranded,
   theme-less page. This adds one:
   - **`/policies`** (index) — lists every policy you've filled in under
     **Settings → Policies** (Refund, Privacy, Terms of Service, Shipping,
     etc.) as a simple Share Tech Mono link list. Policies you haven't
     written are automatically skipped.
   - **`/policies/<handle>`** (e.g. `/policies/refund-policy`) — renders that
     policy's title and body text, with a "← All policies" link back to the
     index.
   - Both routes are **auto-detected by Shopify** the moment
     `templates/policies.json` exists in the theme — no admin setup, no page
     to create, nothing to assign. It just starts working on upload.
   - Runs on the standard layout, so it gets the same nav bar/footer as the
     rest of the site (see item 7).

## No manual setup required

The landing page's **SHOP** nav pill links straight to `/collections/all`
— Shopify's built-in "all products" catalog — so it works immediately after
upload, no admin setup needed. **CONTACT** and **POLICIES** also point at
routes that work immediately: `/pages/contact` (your existing Contact page)
and `/policies` (now styled by `templates/policies.json` — see item 8).

The only thing to check: **Settings → Policies** in your Shopify admin
should have your Refund/Privacy/Terms/Shipping policy text filled in — that's
store content, not theme code, so it can't be shipped in the zip. Any policy
left blank there is simply skipped on the `/policies` index (no broken links,
no errors).

**Optional:** if you'd rather SHOP land on the custom page built from your
old homepage (Hero + Featured Collection + Marquee) instead of the raw
catalog, you can wire that up later:
1. **Online Store → Pages → Add page**, title it `Shop`, set its
   **Theme template** to `page.shop`, save.
2. Customize the theme → `Landing page` section → edit the **SHOP** block's
   **Link** to `/pages/shop`.

**Optional — restyle your nav menu labels to "Home / Catalog / Contact":**
the header's nav links come from your **Main menu** (Online Store →
Navigation), which is store content, not theme code, so it can't be set from
a theme file. To match the reference layout:
1. **Online Store → Navigation → Main menu → Edit**.
2. Set/reorder the links: `Home` → `/`, `Catalog` → `/collections/all`,
   `Contact` → `/pages/contact`.
3. Save. The new Bebas Neue styling applies automatically — no theme changes
   needed for this step.

## After uploading

- **Set the logo image**: Customize the theme → the `Landing page` section →
  set the **Logo image**. Until you do, the section falls back to your store
  name as text so nothing looks broken.
- **Social links**: already pre-filled with the Instagram/YouTube URLs found
  in your footer settings. Editable from the same section in the theme
  editor if they ever change.
- **Nav links**: editable as blocks on the `Landing page` section (label,
  URL, and glow-animation delay per link) — no code changes needed.
- **Contact page copy**: the heading, subheading, back link, and social URLs
  are all editable from Customize → the `Contact page` section — no code
  changes needed there either.
- **Policies index heading**: editable from Customize → the `Policy` section
  on the Policies template, if you ever want something other than "Policies".

## Validation performed

- Every `{% schema %}` block in the theme (138 total) parses as valid JSON.
- `templates/index.json`, `templates/page.shop.json`,
  `templates/page.contact.json`, and `templates/policies.json` are strict,
  valid JSON.
- All Liquid snippets referenced by `layout/landing.liquid`
  (`meta-tags`, `stylesheets`, `fonts`, `scripts`, `theme-styles-variables`,
  `color-palette`, `theme-editor`, `skip-to-content-link`) exist in
  `snippets/`.
- Liquid block tags (`if/endif`, `for/endfor`, `case/endcase`, `form/endform`,
  `schema/endschema`, `stylesheet/endstylesheet`, etc.) are balanced in the
  new files.
- No unresolved translation keys — the sections use static English strings
  where no matching key existed in `locales/en.default.json` (e.g. the nav
  `aria-label`, the contact form's status text), so nothing renders
  "Translation missing."
- The contact form uses the same `contact[name]` / `contact[email]` /
  `contact[body]` field names and `form.posted_successfully?` /
  `form.errors` handling as the theme's own `blocks/contact-form.liquid`,
  so it's a genuine Shopify contact form, not a decorative one.
